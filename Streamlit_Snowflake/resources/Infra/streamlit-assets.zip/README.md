# Interactive Analytics Dashboard with React Components

This project enhances a Streamlit analytics dashboard with interactive React components for better data visualization.

## Features

- Interactive time series charts with React and Chart.js
- Region filtering directly in the chart
- Zoom in/out functionality
- Click events for cross-filtering
- Responsive design

## Setup Instructions

### Prerequisites

- Python 3.7+
- Node.js 14+ and npm

### Installation

1. Install Python dependencies:
   ```
   pip install streamlit pandas numpy pillow plotly
   ```

2. Install Node.js dependencies for the React component:
   ```
   cd components
   npm install
   ```

### Development Mode

To run the dashboard with React components in development mode:

1. Start the React development server:
   ```
   cd components
   npm start
   ```

2. In a separate terminal, run the Streamlit app:
   ```
   streamlit run dashboard_with_react.py
   ```

### Production Mode

For production deployment:

1. Build the React component:
   ```
   cd components
   npm run build
   ```

2. Update the `_RELEASE` flag in `components/timeseries_component.py` to `True`

3. Run the Streamlit app:
   ```
   streamlit run dashboard_with_react.py
   ```

## Component Structure

- `components/TimeseriesChart.jsx`: Main React component for time series visualization
- `components/StreamlitReactAdapter.jsx`: Bridge between Streamlit and React
- `components/timeseries_component.py`: Python interface for the React component
- `dashboard_with_react.py`: Enhanced Streamlit dashboard using the React component

## Usage

The React time series component can be used in any Streamlit app by importing:

```python
from components.timeseries_component import timeseries_chart

# Use the component
clicked_point = timeseries_chart(
    data=df,
    title="My Time Series",
    x_axis_label="Date",
    y_axis_label="Value",
    height=500,
    key="my_timeseries"
)

# Handle click events
if clicked_point:
    st.write("You clicked:", clicked_point)
```