import os
import json
import streamlit as st
import streamlit.components.v1 as components
import pandas as pd

# Define the component directory
COMPONENT_DIR = os.path.dirname(os.path.abspath(__file__))

# Create a _RELEASE flag to determine if we're in development or production mode
_RELEASE = False

# If in development mode, use the local component
if not _RELEASE:
    _component_func = components.declare_component(
        "timeseries_chart",
        url="http://localhost:3001",  # Development server URL
    )
else:
    # In production, use the prebuilt component
    parent_dir = os.path.dirname(COMPONENT_DIR)
    build_dir = os.path.join(parent_dir, "frontend/build")
    _component_func = components.declare_component("timeseries_chart", path=build_dir)

def timeseries_chart(data, title="Time Series Chart", x_axis_label="Date", y_axis_label="Value", height=500, key=None):
    """
    Create a React-based interactive timeseries chart.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        The data to display in the chart. Must contain a 'Date' column and at least one numeric column.
    title : str
        The title of the chart.
    x_axis_label : str
        The label for the x-axis.
    y_axis_label : str
        The label for the y-axis.
    height : int
        The height of the chart in pixels.
    key : str or None
        An optional key that uniquely identifies this component. If this is
        None, and the component's arguments are changed, the component will
        be re-mounted in the Streamlit frontend and lose its current state.
    
    Returns:
    --------
    dict or None
        Returns data about the clicked point if a point was clicked, otherwise None.
    """
    # Convert DataFrame to list of dictionaries for JSON serialization
    if isinstance(data, pd.DataFrame):
        chart_data = data.to_dict('records')
    else:
        chart_data = data
    
    # Create the component value dictionary
    component_value = {
        "chart_data": json.dumps(chart_data),
        "title": title,
        "x_axis_label": x_axis_label,
        "y_axis_label": y_axis_label,
        "height": height
    }
    
    # Call the component function and get the clicked point data
    clicked_data = _component_func(data=component_value, key=key, default=None)
    
    # Return the clicked point data for further processing
    return clicked_data

# Example usage
if __name__ == "__main__":
    import numpy as np
    
    # Create sample data
    dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='D')
    regions = ['North America', 'Europe', 'Asia Pacific']
    
    data = []
    for region in regions:
        for date in dates:
            data.append({
                'Date': date.strftime('%Y-%m-%d'),
                'Region': region,
                'Value': np.random.randint(100, 1000),
                'Another Value': np.random.randint(50, 500)
            })
    
    df = pd.DataFrame(data)
    
    st.title("Timeseries Chart Example")
    
    clicked_point = timeseries_chart(
        data=df,
        title="Sample Timeseries Data",
        x_axis_label="Date",
        y_axis_label="Value",
        height=500,
        key="timeseries_example"
    )
    
    if clicked_point:
        st.write("You clicked on:", clicked_point)