import React from 'react';
import ReactDOM from 'react-dom';
import TimeseriesChart from './TimeseriesChart';

// This component serves as a bridge between Streamlit and React
// It will be loaded by Streamlit's component iframe
class StreamlitReactAdapter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      title: '',
      xAxisLabel: '',
      yAxisLabel: '',
      componentHeight: 500
    };
    
    // Bind methods
    this.onDataFromPython = this.onDataFromPython.bind(this);
    this.sendDataToPython = this.sendDataToPython.bind(this);
  }
  
  componentDidMount() {
    // Set up communication with Streamlit
    window.addEventListener('message', this.onDataFromPython);
    
    // Let Streamlit know the component is ready
    if (window.Streamlit) {
      window.Streamlit.setComponentReady();
    }
  }
  
  componentWillUnmount() {
    window.removeEventListener('message', this.onDataFromPython);
  }
  
  // Handle data coming from Python/Streamlit
  onDataFromPython(event) {
    if (!event.data.hasOwnProperty('isStreamlitMessage')) {
      return;
    }
    
    const data = event.data.args.data;
    if (data) {
      this.setState({
        data: JSON.parse(data.chart_data || '[]'),
        title: data.title || 'Time Series Chart',
        xAxisLabel: data.x_axis_label || 'Date',
        yAxisLabel: data.y_axis_label || 'Value',
        componentHeight: data.height || 500
      });
    }
  }
  
  // Send data back to Python/Streamlit
  sendDataToPython(data) {
    if (window.Streamlit) {
      // Ensure we're sending valid data that can be processed by Streamlit
      const validData = {
        metric: data.metric,
        value: data.value,
        region: data.region,
        date: data.date ? data.date.toISOString() : null
      };
      window.Streamlit.setComponentValue(validData);
    }
  }
  
  render() {
    const { data, title, xAxisLabel, yAxisLabel, componentHeight } = this.state;
    
    return (
      <div style={{ height: componentHeight }}>
        <TimeseriesChart 
          data={data}
          title={title}
          xAxisLabel={xAxisLabel}
          yAxisLabel={yAxisLabel}
          onPointClick={(pointData) => this.sendDataToPython(pointData)}
        />
      </div>
    );
  }
}

// Render the component
ReactDOM.render(
  <StreamlitReactAdapter />,
  document.getElementById('root')
);

export default StreamlitReactAdapter;