import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
  Filler
} from 'chart.js';
import 'chartjs-adapter-date-fns';
import { enUS } from 'date-fns/locale';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
  Filler
);

const TimeseriesChart = ({ data, title, xAxisLabel, yAxisLabel, onPointClick }) => {
  const [chartData, setChartData] = useState(null);
  const [selectedRegions, setSelectedRegions] = useState([]);
  const [availableRegions, setAvailableRegions] = useState([]);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [dateRange, setDateRange] = useState({ start: null, end: null });

  // Process data when it changes
  useEffect(() => {
    if (!data || data.length === 0) return;

    // Extract unique regions
    const regions = [...new Set(data.map(item => item.Region))];
    setAvailableRegions(regions);
    
    // If no regions are selected yet, select all by default
    if (selectedRegions.length === 0) {
      setSelectedRegions(regions);
    }

    // Find min and max dates if not set
    if (!dateRange.start || !dateRange.end) {
      const dates = data.map(item => new Date(item.Date));
      setDateRange({
        start: new Date(Math.min(...dates)),
        end: new Date(Math.max(...dates))
      });
    }

    // Filter data by selected regions
    const filteredData = data.filter(item => selectedRegions.includes(item.Region));

    // Group data by region
    const groupedData = {};
    regions.forEach(region => {
      groupedData[region] = filteredData.filter(item => item.Region === region);
    });

    // Create datasets for Chart.js
    const datasets = [];
    const colorMap = {
      'North America': 'rgba(255, 99, 132, 1)',
      'Europe': 'rgba(54, 162, 235, 1)',
      'Asia Pacific': 'rgba(255, 206, 86, 1)',
      'South America': 'rgba(75, 192, 192, 1)',
      'Africa': 'rgba(153, 102, 255, 1)'
    };

    // Get metrics from first data item (assuming all items have same structure)
    const metrics = Object.keys(data[0]).filter(key => 
      !['Date', 'Region', 'Product Category', 'Traffic Source', 'User Type'].includes(key)
    );

    // Create a dataset for each region and metric
    selectedRegions.forEach(region => {
      const regionData = groupedData[region] || [];
      
      metrics.forEach(metric => {
        // Skip metrics with no data
        if (!regionData[0] || regionData[0][metric] === undefined) return;
        
        const color = colorMap[region] || `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 1)`;
        
        datasets.push({
          label: `${region} - ${metric}`,
          data: regionData.map(item => ({
            x: new Date(item.Date),
            y: item[metric],
            region: item.Region,
            metric: metric
          })),
          borderColor: color,
          backgroundColor: color.replace('1)', '0.1)'),
          borderWidth: 2,
          pointRadius: 3,
          pointHoverRadius: 5,
          tension: 0.3
        });
      });
    });

    setChartData({
      datasets
    });
  }, [data, selectedRegions]);

  const handleRegionToggle = (region) => {
    setSelectedRegions(prev => {
      if (prev.includes(region)) {
        return prev.filter(r => r !== region);
      } else {
        return [...prev, region];
      }
    });
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev * 1.2, 5));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev / 1.2, 0.5));
  };

  const handleReset = () => {
    setZoomLevel(1);
    if (data && data.length > 0) {
      const dates = data.map(item => new Date(item.Date));
      setDateRange({
        start: new Date(Math.min(...dates)),
        end: new Date(Math.max(...dates))
      });
    }
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index',
      intersect: false,
    },
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: title || 'Time Series Chart',
        font: {
          size: 16,
          weight: 'bold'
        }
      },
      tooltip: {
        callbacks: {
          title: (tooltipItems) => {
            return new Date(tooltipItems[0].raw.x).toLocaleDateString();
          },
          label: (tooltipItem) => {
            const value = tooltipItem.raw.y;
            return `${tooltipItem.dataset.label}: ${typeof value === 'number' ? value.toLocaleString() : value}`;
          }
        }
      },
      zoom: {
        zoom: {
          wheel: {
            enabled: true,
          },
          pinch: {
            enabled: true
          },
          mode: 'xy',
        }
      }
    },
    scales: {
      x: {
        type: 'time',
        time: {
          unit: 'day',
          tooltipFormat: 'PP',
          displayFormats: {
            day: 'MMM d'
          }
        },
        title: {
          display: true,
          text: xAxisLabel || 'Date',
        },
        adapters: {
          date: {
            locale: enUS
          }
        },
        min: dateRange.start,
        max: dateRange.end
      },
      y: {
        title: {
          display: true,
          text: yAxisLabel || 'Value',
        },
        beginAtZero: true
      }
    },
    onClick: (event, elements) => {
      if (elements.length > 0) {
        const { datasetIndex, index } = elements[0];
        const clickedData = chartData.datasets[datasetIndex].data[index];
        if (onPointClick) {
          onPointClick({
            date: clickedData.x,
            value: clickedData.y,
            region: clickedData.region,
            metric: clickedData.metric
          });
        }
      }
    }
  };

  if (!chartData) {
    return <div>Loading chart data...</div>;
  }

  return (
    <div style={{ width: '100%', height: '500px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
        <div>
          {availableRegions.map(region => (
            <label key={region} style={{ marginRight: '15px' }}>
              <input
                type="checkbox"
                checked={selectedRegions.includes(region)}
                onChange={() => handleRegionToggle(region)}
              />
              {region}
            </label>
          ))}
        </div>
        <div>
          <button onClick={handleZoomIn} style={buttonStyle}>Zoom In</button>
          <button onClick={handleZoomOut} style={buttonStyle}>Zoom Out</button>
          <button onClick={handleReset} style={buttonStyle}>Reset</button>
        </div>
      </div>
      <div style={{ height: '450px', transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}>
        <Line data={chartData} options={options} />
      </div>
    </div>
  );
};

const buttonStyle = {
  marginLeft: '5px',
  padding: '5px 10px',
  backgroundColor: '#FF9900',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer'
};

export default TimeseriesChart;