import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import datetime
import plotly.express as px
import json

# Load favicon with error handling
try:
    favicon = Image.open('assets/favicon/aws-custom-favicon-kdm.ico')
except FileNotFoundError:
    favicon = None

# Streamlit configuration
st.set_page_config(
    page_title="Analytics Dashboard", 
    page_icon=favicon, 
    layout="wide", 
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #FF9900;
        text-align: center;
    }
    .sub-header {
        font-size: 1.5rem;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
    }
    .filter-badge {
        background-color: #FF9900;
        color: white;
        padding: 0.3rem 0.6rem;
        border-radius: 1rem;
        font-size: 0.8rem;
        margin-right: 0.5rem;
    }
    /* Custom styles for table header filters */
    .stExpander {
        border: none !important;
        box-shadow: none !important;
    }
    .filter-header {
        padding: 0 !important;
        background-color: #f0f2f6;
        border-bottom: 1px solid #ddd;
    }
    .filter-container {
        padding: 0.5rem;
        border-radius: 4px;
    }
    div[data-testid="stVerticalBlock"] > div[data-testid="stHorizontalBlock"] {
        gap: 0 !important;
        margin-bottom: 0 !important;
    }
    /* Make table header sticky */
    .table-header {
        position: sticky;
        top: 0;
        background-color: white;
        z-index: 1;
    }
    /* Compact inputs */
    .filter-container .stDateInput, .filter-container .stNumberInput {
        margin-bottom: 0 !important;
    }
    .filter-container .stSelectbox > div {
        margin-bottom: 0 !important;
    }
</style>
""", unsafe_allow_html=True)

# Header
st.markdown('<p class="main-header">Analytics Dashboard</p>', unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    try:
        st.image("assets/AWS_logo_RGB_REV.png", width=100)
    except:
        st.write("AWS Logo")
    
    try:
        st.image("assets/tf-logo.png", width=100)
    except:
        st.write("Terraform Logo")
    
    st.markdown("### Dashboard Settings")
    date_range = st.date_input(
        "Select Date Range",
        value=(datetime.date.today() - datetime.timedelta(days=30), datetime.date.today())
    )
    
    data_source = st.selectbox(
        "Data Source",
        ["Sales Data", "Website Traffic", "User Engagement"],
        key="data_source_selector"
    )
    
    regions = st.multiselect(
        "Region",
        ["North America", "Europe", "Asia Pacific", "South America", "Africa"],
        default=["North America", "Europe"],
        key="region_selector"
    )
    
    # Add additional filters based on data source
    if data_source == "Sales Data":
        product_categories = st.multiselect(
            "Product Category",
            ["Electronics", "Clothing", "Home Goods", "Books"],
            default=["Electronics", "Clothing"],
            key="product_category_selector"
        )
    elif data_source == "Website Traffic":
        traffic_sources = st.multiselect(
            "Traffic Source",
            ["Organic", "Direct", "Social", "Referral"],
            default=["Organic", "Direct"],
            key="traffic_source_selector"
        )
    else:  # User Engagement
        user_types = st.multiselect(
            "User Type",
            ["New", "Returning", "Loyal"],
            default=["New", "Returning"],
            key="user_type_selector"
        )
    
    # Add time granularity option
    time_granularity = st.selectbox(
        "Time Granularity",
        ["Daily", "Weekly", "Monthly"],
        key="time_granularity_selector"
    )
    
    refresh_button = st.button("Refresh Data", key="refresh_button")

# Generate sample data
def generate_sample_data(data_type, selected_regions=None):
    dates = pd.date_range(date_range[0], date_range[1], freq='D')
    regions_list = selected_regions if selected_regions else ["North America", "Europe", "Asia Pacific", "South America", "Africa"]
    
    # Create empty dataframe to store all data
    all_data = pd.DataFrame()
    
    for region in regions_list:
        # Add some variation based on region
        region_factor = {
            "North America": 1.2,
            "Europe": 1.0,
            "Asia Pacific": 0.9,
            "South America": 0.7,
            "Africa": 0.5
        }.get(region, 1.0)
        
        if data_type == "Sales Data":
            data = {
                'Date': dates,
                'Revenue': np.random.randint(5000, 15000, size=len(dates)) * region_factor,
                'Orders': np.random.randint(100, 500, size=len(dates)) * region_factor,
                'Average Order Value': np.random.randint(50, 150, size=len(dates)),
                'Region': region,
                'Product Category': np.random.choice(['Electronics', 'Clothing', 'Home Goods', 'Books'], size=len(dates))
            }
        elif data_type == "Website Traffic":
            data = {
                'Date': dates,
                'Visitors': np.random.randint(1000, 5000, size=len(dates)) * region_factor,
                'Page Views': np.random.randint(3000, 15000, size=len(dates)) * region_factor,
                'Bounce Rate': np.random.uniform(0.2, 0.6, size=len(dates)),
                'Region': region,
                'Traffic Source': np.random.choice(['Organic', 'Direct', 'Social', 'Referral'], size=len(dates))
            }
        else:  # User Engagement
            data = {
                'Date': dates,
                'Active Users': np.random.randint(500, 2000, size=len(dates)) * region_factor,
                'Session Duration': np.random.uniform(2, 10, size=len(dates)),
                'Conversion Rate': np.random.uniform(0.01, 0.1, size=len(dates)),
                'Region': region,
                'User Type': np.random.choice(['New', 'Returning', 'Loyal'], size=len(dates))
            }
        
        # Append to the all_data dataframe
        region_df = pd.DataFrame(data)
        all_data = pd.concat([all_data, region_df], ignore_index=True)
    
    return all_data

# Apply additional filters based on data source
def filter_dataframe(df, data_source):
    filtered_df = df.copy()
    
    # Apply region filter
    if regions:
        filtered_df = filtered_df[filtered_df['Region'].isin(regions)]
    
    # Apply data source specific filters
    if data_source == "Sales Data" and 'product_categories' in st.session_state:
        categories = st.session_state.get('product_category_selector', [])
        if categories:
            filtered_df = filtered_df[filtered_df['Product Category'].isin(categories)]
    elif data_source == "Website Traffic" and 'traffic_source_selector' in st.session_state:
        sources = st.session_state.get('traffic_source_selector', [])
        if sources:
            filtered_df = filtered_df[filtered_df['Traffic Source'].isin(sources)]
    elif data_source == "User Engagement" and 'user_type_selector' in st.session_state:
        types = st.session_state.get('user_type_selector', [])
        if types:
            filtered_df = filtered_df[filtered_df['User Type'].isin(types)]
    
    return filtered_df

# Apply time granularity
def resample_data(df, granularity):
    df_copy = df.copy()
    if granularity == "Weekly":
        return df_copy.groupby([pd.Grouper(key='Date', freq='W'), 'Region']).mean().reset_index()
    elif granularity == "Monthly":
        return df_copy.groupby([pd.Grouper(key='Date', freq='M'), 'Region']).mean().reset_index()
    else:  # Daily
        return df_copy

# Generate data based on selection
df = generate_sample_data(data_source, regions)

# Apply filters
filtered_df = filter_dataframe(df, data_source)

# Apply time granularity
resampled_df = resample_data(filtered_df, time_granularity)

# Main dashboard
# Key metrics
st.markdown('<p class="sub-header">Key Metrics</p>', unsafe_allow_html=True)
col1, col2, col3, col4 = st.columns